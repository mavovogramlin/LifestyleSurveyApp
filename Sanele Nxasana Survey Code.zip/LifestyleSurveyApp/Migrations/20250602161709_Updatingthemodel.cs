﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LifestyleSurveyApp.Migrations
{
    /// <inheritdoc />
    public partial class Updatingthemodel : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Resposers");

            migrationBuilder.DropColumn(
                name: "Date",
                table: "Surveys");

            migrationBuilder.DropColumn(
                name: "FirstName",
                table: "Surveys");

            migrationBuilder.RenameColumn(
                name: "LastName",
                table: "Surveys",
                newName: "FullName");

            migrationBuilder.AddColumn<string>(
                name: "ContactNumber",
                table: "Surveys",
                type: "nvarchar(10)",
                maxLength: 10,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateOnly>(
                name: "DateOfBirth",
                table: "Surveys",
                type: "date",
                nullable: false,
                defaultValue: new DateOnly(1, 1, 1));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ContactNumber",
                table: "Surveys");

            migrationBuilder.DropColumn(
                name: "DateOfBirth",
                table: "Surveys");

            migrationBuilder.RenameColumn(
                name: "FullName",
                table: "Surveys",
                newName: "LastName");

            migrationBuilder.AddColumn<DateTime>(
                name: "Date",
                table: "Surveys",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "FirstName",
                table: "Surveys",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateTable(
                name: "Resposers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AgeRange = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CoffeeIntake = table.Column<int>(type: "int", nullable: false),
                    DietType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ExerciseFrequency = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FastFoodFrequency = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SleepHours = table.Column<int>(type: "int", nullable: false),
                    SmokeOrDrink = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StressLevel = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SubmittedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Resposers", x => x.Id);
                });
        }
    }
}
